import React, { useEffect } from "react"

function ErrorPage() {
  return <>Unauthorized Access.</>
}

export default ErrorPage
