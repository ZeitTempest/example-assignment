import React, { useEffect } from "react"

function Testing() {
  return (
    <form>
      <input type="text" />
      <input type="text" />
      <input type="text" />
      <input type="text" />
      <input type="text" />
    </form>
  )
}

export default Testing
